3b9eda0668\237bd356482c74bf0c1056ad607eb

- [\] translate
  - [x] mouse drag
  - [ ] touch drag
- [\] zoom / scale
  - [x] mouse wheel
  - [ ] touch pinch
- [x] min zoom set to 1, max zoom to 4
- [x] using offscreencanvas for rendering

e82d430ee6a7e69b4729600a093280b35bc03739

- [x] using webworker to handling data
- [x] fit the plot object inside the canvas
  - [x] object coordinate = [xmin, xmax, ymin, ymax]
  - [x] canvas coordinate = [xmin, xmax, ymin, ymax]
- [x] trace
  - [x] calculate the color for each point
  - [x] draw traces with color gradient
- [ ] layout
  - [ ] axes
    - [ ] tick
      - [ ] label
    - [ ] label
- [ ] todo: understand the wavelength
- [x] spectrum
  - [x] draw multiple line spectrums, base on the data change
    - [x] always draw new line at start
    - [x] from start, put prev spectrum
- [ ] theme
  - [ ] dark
  - [ ] light
- [ ] scroll speed
